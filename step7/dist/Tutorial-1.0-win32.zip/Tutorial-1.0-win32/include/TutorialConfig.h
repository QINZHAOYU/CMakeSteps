// 项目的配置选项和设置（头文件的版本号），用于生成TutorialConfig.h。
#define Tutorial_VERSION_MAJOR 1
#define Tutorial_VERSION_MINOR 0
#define USE_MYMATH
